public class CityLink extends BusFeatures
{
    
    public CityLink()
    {
        super();
        allTrips[0] = new Trip(201,"Galway","Athlone","10/12/2020","10:00 am","10/12/2020","11:30 am",10,50);
        allTrips[1] = new Trip(202,"Galway","Waterford","12/12/2020","12:00 pm","12/12/2020","5:15 pm",20,30);
        allTrips[2] = new Trip(203,"Galway","Limerick","14/12/2020","8:00 am","14/12/2020","10:00 am",15,55);
    }
    @Override
    public void getAllTrips()
    {
        for(int i=0;i<allTrips.length;i++)
        {
            System.out.println("Company: City-Link");
            System.out.println("Trip ID :"+allTrips[i].getID());
            System.out.println("Orgin :"+allTrips[i].getStartLocation());
            System.out.println("Destination :"+allTrips[i].getDestination());
            System.out.println("Departure date :"+allTrips[i].getDod());
            System.out.println("Departure time :"+allTrips[i].getTod());
            System.out.println("Arrival date :"+allTrips[i].getDoa());
            System.out.println("Arrival time :"+allTrips[i].getToa());
            System.out.println("Fare :"+allTrips[i].getFare()+"$ per passenger");
            System.out.println("Currently available Number of Seats :"+allTrips[i].getNoOfSeats());
            System.out.println(" ");
        }
    }
    public Trip getTrip(int id)
    {
        for( int i =0;i<allTrips.length;i++)
        {
            if(allTrips[i].getID() == id)
                return allTrips[i];
        }
        return null;
    }
     @Override
    public boolean getBooking(Booking booking)
    { 
        if(booking.trip.NoOfSeats>0 && booking.trip.NoOfSeats <= booking.NoOfPassengers)
        {
           booking.trip.NoOfSeats -= booking.NoOfPassengers;
           return true;
        }
        return false;
    }
        
}