public class BusEirean extends BusFeatures
{
    public BusEirean()
    {
        super();
        allTrips[0] = new Trip(301,"Galway","Dublin Airport","12/12/2020","11:00 am","12/12/2020","2:30 pm",22,60);
        allTrips[1] = new Trip(302,"Galway","Leitrim","13/12/2020","10:00 am","13/12/2020","1:15 pm",15,20);
        allTrips[2] = new Trip(303,"Galway","Derry","16/12/2020","9:00 am","16/12/2020","2:00 pm",30,25);
    }
     @Override
    public void getAllTrips()
    {
        for(int i=0;i<allTrips.length;i++)
        {
            System.out.println("Company: Bus-Eirean");
            System.out.println("Trip ID :"+allTrips[i].getID());
            System.out.println("Orgin :"+allTrips[i].getStartLocation());
            System.out.println("Destination :"+allTrips[i].getDestination());
            System.out.println("Departure date :"+allTrips[i].getDod());
            System.out.println("Departure time :"+allTrips[i].getTod());
            System.out.println("Arrival date :"+allTrips[i].getDoa());
            System.out.println("Arrival time :"+allTrips[i].getToa());
            System.out.println("Fare :"+allTrips[i].getFare()+"$ per passenger");
            System.out.println("Currently available Number of Seats :"+allTrips[i].getNoOfSeats());
            System.out.println(" ");
        }
    }
    public Trip getTrip(int id)
    {
        for( int i =0;i<allTrips.length;i++)
        {
            if(allTrips[i].getID() == id)
                return allTrips[i];
        }
        return null;
    }
    @Override
    public boolean getBooking(Booking booking)
    { 
        if(booking.trip.NoOfSeats>0 && booking.trip.NoOfSeats >= booking.NoOfPassengers)
        {
           booking.trip.NoOfSeats -= booking.NoOfPassengers;
           return true;
        }
        return false;
    }
        
}