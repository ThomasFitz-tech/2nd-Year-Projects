public  class Trip
{
    public String StartLocation;
    public String destination;
    public String dod;
    public String tod;
    public String doa;
    public String toa;
    public int fare;
    public int id;
    public int NoOfSeats;
    public Trip(int id,String StartLocation,String destination,String dod,String tod,String doa,String toa, int fare,int NoOfSeats)
    {
        this.id = id;
        this.StartLocation = StartLocation;
        this.destination =  destination;
        this.dod = dod;
        this.tod = tod;
        this.doa = doa;
        this.toa = toa;
        this.fare = fare;
        this.NoOfSeats = NoOfSeats;
    }
    public int getNoOfSeats()
    {
        return NoOfSeats;
    }
    public int getID()
    {
        return id;
    }
    public String getStartLocation()
    {
        return StartLocation;
    }
    public String getDestination()
    {
        return destination;
    }
    public String getDod()
    {
        return dod;
    }
    public String getDoa()
    {
        return doa;
    }
    public String getTod()
    {
        return tod;
    }
    public String getToa()
    {
        return toa;
    }
    public int getFare()
    {
        return fare;
    }
}