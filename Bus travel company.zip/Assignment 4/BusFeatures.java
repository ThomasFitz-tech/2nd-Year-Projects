public abstract class BusFeatures
{
    Trip[] allTrips = new Trip[3];
    public abstract void getAllTrips();
    public abstract boolean getBooking(Booking b);
}