public class Booking
{
    public int NoOfPassengers;
    public float TotalCost;
    public Trip trip;
    public Booking(Trip trip,int NoOfPassengers)
    {
        this.trip = trip;
        this.NoOfPassengers = NoOfPassengers;
    }
    public float getTotal()
    {
        TotalCost = (NoOfPassengers) * (trip.getFare());
        return TotalCost;
    }
    public int getNoOfPassengers()
    {
        return NoOfPassengers;
    }
}