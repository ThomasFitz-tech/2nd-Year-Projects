public class TravelIrelandTest
{
    public static void main(String[] args)
    {
        BusEirean be = new BusEirean();
        GoBus gb = new GoBus();
        CityLink cl = new CityLink();
        be.getAllTrips();
        gb.getAllTrips();
        cl.getAllTrips();
        Trip SelectedTrip = be.getTrip(301);
        Booking booking = new Booking(SelectedTrip,15);
        boolean success = be.getBooking(booking);
        if(success)
        {
            System.out.println("\nORDER SUCCESSFUL!");
            System.out.println("=============================================");
            System.out.println("Number of Passengers :"+booking.getNoOfPassengers());
            System.out.println("Trip Details :"+booking.trip.getStartLocation()+" to "+booking.trip.getDestination());
            System.out.println("Trip ID : "+booking.trip.getID());
            System.out.println("Total cost: "+booking.getTotal());
        }
        else
        {
            System.out.println("\n\nBOOKING FAILED\n\n");
        }
        be.getAllTrips();
    }
}