public class GoBus extends BusFeatures
{
    
    public GoBus()
    {
        super();
        allTrips[0] = new Trip(100,"Galway","Dublin","11/12/2020","10:00 am","11/12/2020","1:30 pm",12,60);
        allTrips[1] = new Trip(101,"Galway","Cork","14/12/2020","9:00 am","14/12/2020","1:00 pm",18,100);
        allTrips[2] = new Trip(102,"Galway","Belfast","16/12/2020","10:00 am","16/12/2020","2:00 pm",20,55);
    }
    @Override
    public void getAllTrips()
    {
        for(int i=0;i<allTrips.length;i++)
        {
            System.out.println("Company: GoBus");
            System.out.println("Trip ID :"+allTrips[i].getID());
            System.out.println("Orgin :"+allTrips[i].getStartLocation());
            System.out.println("Destination :"+allTrips[i].getDestination());
            System.out.println("Departure date :"+allTrips[i].getDod());
            System.out.println("Departure time :"+allTrips[i].getTod());
            System.out.println("Arrival date :"+allTrips[i].getDoa());
            System.out.println("Arrival time :"+allTrips[i].getToa());
            System.out.println("Fare :"+allTrips[i].getFare()+"$ per passenger");
            System.out.println("Currently available Number of Seats :"+allTrips[i].getNoOfSeats());
            System.out.println(" ");
        }
    }
    public Trip getTrip(int id)
    {
        for( int i =0;i<allTrips.length;i++)
        {
            if(allTrips[i].getID() == id)
                return allTrips[i];
        }
        return null;
    }
    @Override
    public boolean getBooking(Booking booking)
    { 
        if(booking.trip.NoOfSeats>0 && booking.trip.NoOfSeats <= booking.NoOfPassengers )
        {
           booking.trip.NoOfSeats -= booking.NoOfPassengers;
           return true;
        }
        return false;
    }        
}