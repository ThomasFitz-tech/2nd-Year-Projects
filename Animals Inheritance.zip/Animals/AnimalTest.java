package Animals;

public class AnimalTest
{
    public static void main(String[] args){
        AnimalTest test = new AnimalTest();
        test.test1();
        test.test2();
    }
    
    public void test1(){
        Animal[] animals = new Animal[4];
        animals[0] = new Ostrich("Sean");
        animals[1] = new Canary("Bob");
        animals[2] = new Trout("Tom");
        animals[3] = new Shark("Baby");
        
        for(int i=0; i<4; i++){
            System.out.println(animals[i]);
            animals[i].move(5);
}
}

    public void test2(){
        Animal[] animals = new Animal[4];
        animals[0] = new Ostrich("Sean");
        animals[1] = new Canary("Bob");
        animals[2] = new Trout("Tom");
        animals[3] = new Shark("Baby");
        Object[] objects = new Object[4];
        Object obj = animals[0];
        Object obj1 = animals[1];
        Object obj2 = animals[2];
        Object obj3 = animals[3];
        
            
        System.out.println("\n \n \n");
        
        /*for(int i=0; i<4; i++){*/
        
        boolean animal1 = animals[0].equals(obj);
        System.out.println(animal1);
        
        boolean animal2 = animals[1].equals(obj1);
        System.out.println(animal2);
        
        boolean animal3 = animals[2].equals(obj2);
        System.out.println(animal3);
        
        boolean animal4 = animals[3].equals(obj3);
        System.out.println(animal4);
}
}
        
 