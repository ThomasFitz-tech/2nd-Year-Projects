package Animals;

public class Trout extends Fish
{
    
    String name; // the name of this Canary

    public Trout(String name)
    {
        super(); // call the constructor of the superclass Bird
        this.name = name;
        colour = "Brown"; // overrides the value inherited from Fish
        bites = false;
        dangerous = false;
        hasSpikes = true;
        laysEggs = true;
        isEdible = true;
        livesInRiver = true;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getName()
    {
        return name;
    }
    
    
    /**
     * toString method returns a String representation of the bird
     * What superclass has Canary inherited this method from? 
     */
    @Override
    public String toString(){
        String strng ="";
        strng+= "\n\tTROUT";
        strng+= "\nName: ";
        strng+= name;
        strng+= "\nColour: ";
        strng+= getColour();
        strng+= "\nSpikey? ";
        strng+= isSpikey(hasSpikes);
        strng+= "\nEdibile? ";
        strng+= canIBeEaten(isEdible);
        strng+= "\nDangerous? ";
        strng+= isDangerous(dangerous);
        strng+= "\nHas gills? ";
        strng+= getGills(hasGills);
        strng+= "\nHas fins? ";
        strng+= getFins(hasFins);
        strng+= "\nLays eggs? ";
        strng+= reproduction(laysEggs);
        return strng;
    }
    
    @Override
    public boolean equals(Object obj)
    {
        if(obj==null)
            return false;
            
        if(obj instanceof Trout)
        {
            Trout trout = (Trout)obj;
            if(this.getName()==(trout.getName()) && this.getColour()==(trout.getColour()) && this.getBreathes()==(trout.getBreathes()) && this.getHasSkin()==(trout.getHasSkin()) && this.getEats()==(trout.getEats()) && this.getHasFins()==(trout.getHasFins()) && this.getHasGills()==(trout.getHasGills())&& this.getDangerous()==(trout.getDangerous()) && this.getBites()==(trout.getBites()) && this.getHasSpikes()==(trout.getHasSpikes()) && this.getLaysEggs()==(trout.getLaysEggs()) && this.getIsEdible()==(trout.getIsEdible()) && this.getLivesInRiver()==(trout.getLivesInRiver()));
                return true;
        }
           return false;
    }

}


