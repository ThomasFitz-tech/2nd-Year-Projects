package Animals;

public class Shark extends Fish
{   
    String name; // the name of this Canary

    public Shark(String name)
    {
        super(); // call the constructor of the superclass Bird
        this.name = name;
        colour = "Grey"; // this overrides the value inherited from Bird
        hasSpikes = false;
        laysEggs = false;
        isEdible = false;
        livesInRiver = false;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getName()
    {
        return name;
    }
            
    /**
     * toString method returns a String representation of the bird
     * What superclass has Canary inherited this method from? 
     */
    @Override
    public String toString(){
        String strng ="";
        strng+= "\n\tSHARK";
        strng+= "\nName: ";
        strng+= name;
        strng+= "\nColour: ";
        strng+= colour;
        strng+= "\nSpikey? ";
        strng+= isSpikey(hasSpikes);
        strng+= "\nEdibile? ";
        strng+= canIBeEaten(isEdible);
        strng+= "\nDangerous? ";
        strng+= isDangerous(dangerous);
        strng+= "\nHas gills? ";
        strng+= getGills(hasGills);
        strng+= "\nHas fins? ";
        strng+= getFins(hasFins);
        strng+= "\nLays eggs? ";
        strng+= reproduction(laysEggs);
        return strng;
    }

        public boolean equals(Object obj)
    {
        if(obj==null)
            return false;
            
        if(obj instanceof Shark)
        {
            Shark shark = (Shark)obj;
            if(this.getName()==(shark.getName()) && this.getColour()==(shark.getColour()) && this.getBreathes()==(shark.getBreathes()) && this.getHasSkin()==(shark.getHasSkin()) && this.getEats()==(shark.getEats()) && this.getHasFins()==(shark.getHasFins()) && this.getHasGills()==(shark.getHasGills())&& this.getDangerous()==(shark.getDangerous()) && this.getBites()==(shark.getBites()) && this.getHasSpikes()==(shark.getHasSpikes()) && this.getLaysEggs()==(shark.getLaysEggs()) && this.getIsEdible()==(shark.getIsEdible()) && this.getLivesInRiver()==(shark.getLivesInRiver()));
                return true;
        }
           return false;
    }
    
}
