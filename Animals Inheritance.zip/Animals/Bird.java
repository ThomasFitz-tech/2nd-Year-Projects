package Animals;


public abstract class Bird extends Animal
{
    //instance variables (fields)
    boolean hasFeathers;
    boolean hasWings;
    boolean canFly;
    boolean canSing;
    boolean longLegs;
    

    /**
     * Constructor for objects of class Bird
     */
    public Bird()
    {
        super(); //calls the constructor of its superclass  - Animal
        colour = "black"; //overrides the value of colour inherited from Animal
        hasFeathers = true; //all the subclasses of Bird inherit this property and value
        hasWings = true; //all the subclasses of Bird inherit this property and value
        canFly = true; //all the subclasses of Bird inherit this property and value
        canSing = true; //all the subclasses of Bird inherit this property and value
        longLegs = false; 
    }
    
    public String getWings(boolean hasWings){
        String str1;
            if(hasWings){
        str1 = "I have wings.";
    }else 
    {
        str1 = "I do not have any wings.";
    }
    return str1;
    }

    public String getFeathers(boolean hasFeathers){
        String str1;
            if(hasFeathers){
        str1 = "I have feathers.";
    }else 
    {
        str1 = "I do not have any feathers.";
    }
    return str1;
    }

    public String sing(boolean canSing){
        String str1;
        if(canSing)
        {
        str1 = "tweet tweet";
    }else {
        str1 ="I do not sing but I can make other noises.";
            }
        return str1;
    }
    
    public String longThinLegs(boolean longLegs){
        String str1;
        if(longLegs)
        {
        str1 = "I have long legs. Therefore, I am a tall bird.";
    }else {
        str1 = "I do not have long legs. Therefore, I am not a tall bird.";
    }
        return str1;
    }

    /**
     * move method overrides the move method
     * inherited from superclass Animal
     */
    @Override // good programming practice to use @Override to denote overridden methods
    public void move(int distance){
        if(canFly){
        System.out.printf("I fly %d metres \n", distance);
        }
        else{
        System.out.printf("I am a bird, but I do not fly. I walk %d metres \n", distance);
        }    
    }
    
    public boolean getHasWings(){
        return hasWings;
   }
   
   public boolean getHasFeathers(){
        return hasFeathers;
   }
   
   public boolean getCanFly(){
        return canFly;
   }
   
     
   public boolean getCanSing(){
        return canSing;
   }
   
   public boolean getLongLegs(){
        return longLegs;
   }
}
