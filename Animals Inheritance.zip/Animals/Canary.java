package Animals;


public class Canary extends Bird
{
    
    String name; // the name of this Canary

    /**
     * Constructor for objects of class Canary
     */
    public Canary(String name)
    {
        super(); // call the constructor of the superclass Bird
        this.name = name;
        colour = "yellow"; // this overrides the value inherited from Bird
        
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getName()
    {
        return name;
    }
    
    /**
     * toString method returns a String representation of the bird
     * What superclass has Canary inherited this method from? 
     */
    @Override
    public String toString(){
        String strng ="";
        strng+= "\n\tCANARY";
        strng+= "\nName: ";
        strng+= name;
        strng+= "\nColour: ";
        strng+= colour;
        strng+= "\nWings? ";
        strng+= getWings(hasWings);
        strng+= "\nFeathers? ";
        strng+= getFeathers(hasFeathers);
        strng+= "\nSings? ";
        strng+= sing(canSing);
        strng+= "\nLong legs? ";
        strng+= longThinLegs(longLegs);
        return strng;
    }

    
    /**
     * equals method defines how equality is defined between 
     * the instances of the Canary class
     * param Object
     * return true or false depending on whether the input object is 
     * equal to this Canary object
     */
    
    @Override
    public boolean equals(Object obj){
        if(obj==null)
            return false;
            
        if(obj instanceof Canary)
        {
            Canary canary = (Canary)obj;
            if(this.getName()==(canary.getName()) && this.getColour()==(canary.getColour()) && this.getBreathes()==(canary.getBreathes()) && this.getHasSkin()==(canary.getHasSkin()) && this.getEats()==(canary.getEats()) && this.getHasWings()==(canary.getHasWings()) && this.getHasFeathers()==(canary.getHasFeathers())&& this.getCanFly()==(canary.getCanFly()) && this.getLongLegs()==(canary.getLongLegs())&& this.getCanSing()==(canary.getCanSing()));
                return true;
        }
           return false;
    }
}
