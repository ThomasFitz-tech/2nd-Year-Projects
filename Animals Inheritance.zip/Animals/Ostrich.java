package Animals;

public class Ostrich extends Bird
{
    
    String name; // the name of the Ostrich
    public Ostrich(String name)
    {
        super(); // calls the constructor of the superclass Bird
        this.name = name;
        colour = "Black";   // this overrides the value inherited from Bird
        canFly = false;     //overriding the flies from true to false as ostrich's cannot fly
        canSing = false;    //overriding the sings from true to false as ostrich's cannot sing
        longLegs = true;
        
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public String getName()
    {
        return name;
    }
    
    /**
     * toString method returns a String representation of the bird
     * What superclass has Canary inherited this method from? 
     */
    @Override
    public String toString(){
        String strng ="";
        strng+= "\n\tOSTRICH";
        strng+= "\nName: ";
        strng+= name;
        strng+= "\nColour: ";
        strng+= colour;
        strng+= "\nWings? ";
        strng+= getWings(hasWings);
        strng+= "\nFeathers? ";
        strng+= getFeathers(hasFeathers);
        strng+= "\nSings? ";
        strng+= sing(canSing);
        strng+= "\nLong legs? ";
        strng+= longThinLegs(longLegs);
        return strng;
    }

    @Override
    public boolean equals(Object obj)
    {
        if(obj==null)
            return false;
            
        if(obj instanceof Ostrich)
        {
            Ostrich ostrich = (Ostrich)obj;
            if(this.getName()==(ostrich.getName()) && this.getColour()==(ostrich.getColour()) && this.getBreathes()==(ostrich.getBreathes()) && this.getHasSkin()==(ostrich.getHasSkin()) && this.getEats()==(ostrich.getEats()) && this.getHasWings()==(ostrich.getHasWings()) && this.getHasFeathers()==(ostrich.getHasFeathers())&& this.getCanFly()==(ostrich.getCanFly()) && this.getLongLegs()==(ostrich.getLongLegs())&& this.getCanSing()==(ostrich.getCanSing()));
                return true;
        }
           return false;
    }
}


