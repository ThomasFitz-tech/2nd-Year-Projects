package Animals;

public abstract class Fish extends Animal
{
    // instance variables - replace the example below with your own
    String name;
    boolean hasGills;
    boolean hasFins;
    boolean swims;
    boolean bites;
    boolean dangerous;
    boolean hasSpikes;
    boolean laysEggs;
    boolean isEdible;
    boolean livesInRiver;
    public Fish()
    {
        super(); //calls the constructor of its superclass - Animal.
        colour = "Silver"; //overrides the value of colour inherited from Animal
        hasFins = true; //all the subclasses of Fish inherit this property and value
        hasGills = true;    //all the subclasses of Fish inherit this property and value
        swims = true;       //all the subclasses of Fish inherit this property and value
        bites = true;
        dangerous = true;
        hasSpikes = true;
        laysEggs = true;
        isEdible = true;
        livesInRiver = true;
    }
    
    public String getFins(boolean hasFins){
        String str1;
            if(hasFins){
        str1 = "I have fins";
    }else 
    {
        str1 = "I do not have fins";
    }
    return str1;
    }
    
    public String getGills(boolean hasGills){
        String str1;
            if(hasGills){
        str1 = "I have gills";
    }else 
    {
        str1 = "I do not have gills";
    }
    return str1;
    }
    
    @Override //SWIM METHOD
    public void move(int distance){
    if(swims){
        System.out.printf("I swim %d metres \n", distance);
    }else 
    {
        System.out.printf("I cannot swim \n");
    }    
    }
    
    public String vicious(boolean bites){
        String str1;
        if(bites){
        str1 = "yum yum yum";
    }else {
        str1 = "I do not bite, I am a safe fish";
    }
    return str1;
}
    
    public String isDangerous(boolean dangerous){
        String str1;
        if(dangerous){
    
            if(bites){
        str1 = "I am dangerous and I can bite";
    }else 
        str1 = "I am not dangerous but I look dangerous";
    }
      
    else {
        str1 = "I am not dangerous at all";
            }
    return str1;
    }
    
    public String isSpikey(boolean hasSpikes){
        String str1;
        if(hasSpikes){
        str1 = "I have sharp spikes";
    }else {
        str1 = "I have no spikes";
    }
        return str1;
    }
    
    public String reproduction(boolean laysEggs){
        String str1;
        if(laysEggs){
            
            if (livesInRiver){
            str1 = "I swim up river to lay eggs";
            }else 
            str1 = "I do not live in a river. I lay eggs at sea";
            
        }else {
        str1 ="I do not lay eggs. I give birth.";
            }
    return str1;
    }
    
    public String canIBeEaten(boolean isEdible){
        String str1;
        if(isEdible){
        str1 = "I am edible";
    }else {
        str1 = "I am not edible, do not me";
    }
        return str1;
    }
    
   
   public boolean getHasFins(){
        return hasFins;
   }
   
   public boolean getHasGills(){
        return hasGills;
   }
   
   public boolean getDangerous(){
        return dangerous;
   }
   
   public boolean getBites(){
        return bites;
   }
   
   public boolean getHasSpikes(){
        return hasSpikes;
   }
   
   public boolean getLaysEggs(){
        return laysEggs;
   }
   
   public boolean getIsEdible(){
        return isEdible;
   }
   
   public boolean getLivesInRiver(){
        return livesInRiver;
   }
}
