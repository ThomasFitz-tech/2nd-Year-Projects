
/**
 * Write a description of class Payment here.
 *
 * @author (Thomas Fitzmaurice)
 * @version (a version number or a date)
 */
public class Payment
{
    private Customer customer;
    private String CrCardType;
    private double CrCardNo;
    private String date;
    private Address address;
    private String BankName;
    private boolean valid;
    
    public Payment(Customer customer, Address address ,String cardtype, double cardno, String bankname, String date )
    {
        this.customer = customer;
        CrCardType = cardtype;
        CrCardNo = cardno;
        this.date = date;
        this.address = address;
        BankName = bankname;
        valid = true;
    }    
    
    public void CheckCardType()
    {
        if(CrCardType != "MasterCard" && CrCardType != "Visa")
        {
            valid = false;
        }    
    }  
    
    public void CheckCardNo()
    {
        if(CrCardNo < 100 || CrCardNo > 9999)
        {
            valid = false;
        }
    }
    
    public boolean isValid()
    {
        return valid;
    }  
    
    
    public Customer  getCustomer()
    {
        return customer;
    } 
    
    public Address getAddress()
    {
        return address;
    }  
    
   
    
    public double getCardNo()
    {
        return CrCardNo;
    }  
    
    public String getDate()
    {
        return date;
    }  
    
    public String getBankName()
    {
        return BankName;
    }  
    
}
