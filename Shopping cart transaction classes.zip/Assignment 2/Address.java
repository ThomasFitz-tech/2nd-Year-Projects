
/**
 * Write a description of class Address here.
 *
 * @author (Thomas Fitzmaurice)
 * @version (a version number or a date)
 */
public class Address
{
    private String street;
    private String city;
    private String zipcode;
    private String country;
    
    public Address(String street, String city, String zipcode, String country)
    {
        this.street  = street;
        this.city = city;
        this.zipcode = zipcode;
        this.country = country;
    }
    
    public String getStreet()
    {
        return street;
    }
    
    public String getCity()
    {
        return city;
    }
    
    public String getZipcode()
    {
        return zipcode;
    }
    
    public String getCountry()
    {
        return country;
    }
}
