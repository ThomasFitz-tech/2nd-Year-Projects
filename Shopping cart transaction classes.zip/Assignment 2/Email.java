
/**
 * Write a description of class Email here.
 *
 * @author (Thomas Fitzmaurice)
 * @version (a version number or a date)
 */
public class Email
{
    private Order order;
    
    public Email(Order order)
    {
        this.order = order;
    }
    
    public void emailCustomer()
    {
        System.out.println(order.email());
        System.out.println("Total cost:" +order.getTotal());
    }
}
