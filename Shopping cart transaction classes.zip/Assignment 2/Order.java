
/**
 * Write a description of class Order here.
 *
 * @author (Thomas Fitzmaurice)
 * @version (a version number or a date)
 */
import java.io.*;
import java.util.ArrayList; //importing java classes
import java.util.List;
import java.util.Random;

public class Order
{
    private ShoppingCart cart;
    private Email email;
    private Payment payment;
    private Address address1;
    private Address address2;
    private Customer customer;
    private int OrderNumber;
    private String OrderStatus;
    private String OrderDetails;
    private ArrayList<Item> group; // array to get the items from the shopping cart array
    private String emails;
    
    public Order(ShoppingCart cart, Address address1, Address address2, Payment payment, Customer customer)
    {
        this.cart = cart;
        this.address1 = address1;
        this.address2 = address2;
        this.payment = payment;
        this.customer = customer;
        group = new ArrayList<>();
        OrderStatus = " ";
        OrderDetails = " ";
        OrderNumber = 0;
        emails = " ";
        
    }
    
    public void ProcessOrder()
    {
       //to get the value of the array list from shopping cart
       for(int i=0; i<cart.numItems(); i++)
       {
        group.add(cart.getItem(i));
       }
       cart.clear(); //clears the shopping cart
    }
    
    public String getOrderStatus()
    {
        // cxhecks if the payment is valid and prints the order status
        if(payment.isValid())
        {
            OrderStatus = "Status positive";
        }
        else
        {
            OrderStatus = "Status negative";
        }
        return(OrderStatus);
        
    }
    
    public Item getItem(int index)
    {
        if(group.get(index) != null)//reads in an index and returns the Item at that index
        {
            return group.get(index);
        }
        else //there is no item at index
        {
            System.out.println("This item does not exist");
            return null;
        }
    }
    
    public int numItems()
    {
        return group.size(); //returns array size
    }
    
    public String getOrderDetails()
    {
        // stores all the items and its fields in a string
        for(int i=0; i<numItems(); i++)
        {
            OrderDetails += getItem(i).toString();
        }
        return(OrderDetails); //returns order details
    }
    
    public int getOrderNumber()
    {
        Random rand = new Random(); //creates an object fro random class
        OrderNumber = rand.nextInt(100000); // creates an integer between 0 an 99999
        return OrderNumber; //returns the integer
    }
    
    public String email()
    {
        if (payment.isValid()) // checks if the payment is valid
        {
        // filing out details for the email
        emails += "To:" +customer.getEmail();
        emails += "\nDear, " +customer.getFirstName();
        emails += "\nYour order and payment have been successfully made ";
        emails += "\nOrder number: " +getOrderNumber();
        emails += "\nOrder details: " +getOrderDetails();
        emails += "\nBilling address: " +address1.getStreet()+ "," +address1.getCity()+",";
        emails += address1.getCountry()+ "\t" +address1.getZipcode();
        emails += "\nDelivery address: " +address2.getStreet()+ "," +address2.getCity()+",";
        emails += address2.getCountry()+ "\t" +address2.getZipcode();
        }
        else
        {
            //If payment is not valid send this email
            emails += "To:" +customer.getEmail();
            emails += "\nDear, " +customer.getFirstName();
            emails += "\nYour order and payment have been unsuccessful";
        }
        return emails; //returns the emails
    }
    
    public double getTotal()
    {
        return (cart.getTotal()); //return total
    }
        
    
    
}
