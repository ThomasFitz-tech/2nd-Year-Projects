
/**
 * Write a description of class ShoppingCart here.
 *
 * @author (Thomas Fitzmaurice)
 * @version (a version number or a date)
 */
import java.io.*;
import java.util.ArrayList; //importing java classes
import java.util.List;

public class ShoppingCart
{
    private double cartID; // unique numerical id for the cart
    private String time; //date/tiem it was created
    private double total; //shoppingcart fields
    private Item item; //hold the itesm in the cart
    private Customer customer;
    private ArrayList<Item> group; // array to store all items
    private boolean check; // to check if the shopping cart is closed
    
    public ShoppingCart (Customer customer,double cartID, String time)
    {
        group = new ArrayList<>();
        this.cartID = cartID;
        this.time = time;
        this.customer = customer;
        total = 0.0;
        check = false;
    }
    
    public void addItem(Item s)
    {
        if (check == false)
        {
            // Reads in an item object and adds it to the shopping cart
            group.add(s);
            total+= s.getPrice(); //gives the total price 
        }
        else
        System.out.println("Sorry the shopping cart is closed"); // tells us the shopping cart is closed
    }
    
    public double getTotal()
    {
        return total; //gives us the total cost
    }
    
    public void displayTotal()
    {
        System.out.println("Total cost:" +total); // prints out the total cost
    }
    
    public Item getItem(int index)
    {
        if(group.get(index) != null)//reads in an index and returns the Item at that index
        {
            return group.get(index);
        }
        else //there is no item at that index
        {
            System.out.println("This item does not exist");
            return null;
        }
    }
    
    public double getCartID()
    {
        return cartID; //returns card id
    }
    
    public Customer getCustomer()
    {
        return customer; //returns customer
    }
    
    public boolean removeItem(int index)
    {
        boolean i = true; //returning if item is removed or not
        if(check == false) // ensures the cart is open
        {
            if(group.get(index) != null) //if item exuists
            {
            group.remove(index); // removees item
            total-= getItem(index).getPrice();
            i = true;
            }
            else
            {
                i = false; // no item in index specifired
            }
        }
        else
        System.out.println("Sorry the shopping cart is closed");
        return i;
    }
    
    public int numItems()
    {
        return group.size(); //returns array size
    }
    
    public void printItems()
    {
        if (numItems()>0) // if an item exists
        {
            for(int i=0; i<numItems(); i++)
            {
                System.out.println(getItem(i).toString()); //prints all item fields for each item in list
            }
        }
        else
        {
            System.out.println("This group is empty"); //prints if the list is empty
        }
    }
    
    public void close()
     {
        check = true; //
     }
        
    public void clear()
    {
            check = false; // enables us to clear even if the list is closed
            for(int i=0; i<numItems(); i++)// removers every item in the list
            {
                group.remove(i);
            }
    }
    
}
