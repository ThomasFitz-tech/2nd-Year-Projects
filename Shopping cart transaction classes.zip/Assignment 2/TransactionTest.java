
/**
 * Write a description of class TransactionTest here.
 *
 * @author (Thomas Fitzmaurice)
 * @version (a version number or a date)
 */
public class TransactionTest
{
    public static void main(String[] args)
    {
        TransactionTest test = new TransactionTest();
        test.transaction1(); // calls the method with our test scenario
        test.transaction2();
        
    }
    
    public void transaction1()
    {
        //body of our first code scenario will go here
        Customer customer = new Customer("Thomas", "Fitzmaurice", "thomasf@zmail.com"); //New customer
        ShoppingCart cart = new ShoppingCart(customer, 2468, "06/11/2020");// Shopping Cart for the Customer
        Item item1 = new Item("Milk", 10);
        Item item2 = new Item("Bread", 11);
        Item item3 = new Item("Butter", 12);
        item1.setPrice(1);
        item2.setPrice(1);
        item3.setPrice(1);
        cart.addItem(item1);
        cart.addItem(item2);
        cart.addItem(item3);
        Address address1 = new Address("streeta", "citya", "zipcodea", "countrya");
        Address address2 = new Address("streetb", "cityb", "zipcodeb", "countryb");
        Payment payment = new Payment(customer, address1,"Visa", 2468, "BankofIreland", "06/11/2020");
        Order order = new Order(cart, address1, address2, payment, customer);
        payment.CheckCardType();
        payment.CheckCardNo();
        order.ProcessOrder();
        Email email = new Email(order);
        email.emailCustomer();
        
    }
    
    public void transaction2()
    {
        //body of another code scenario will go here
        Customer customer = new Customer("Thomas", "Fitzmaurice", "thomasf@zmail.com");
        ShoppingCart cart = new ShoppingCart(customer, 2468, "06/11/2020");
        Item item1 = new Item("Milk", 10);
        Item item2 = new Item("Bread", 11);
        Item item3 = new Item("Butter", 12);
        item1.setPrice(1);
        item2.setPrice(1);
        item3.setPrice(1);
        Address address1 = new Address("streeta", "citya", "zipcodea", "countrya");
        Address address2 = new Address("streetb", "cityb", "zipcodeb", "countryb");
        Payment payment = new Payment(customer, address1,"NasterCard", 48, "BankofIreland", "06/11/2020");
        Order order = new Order(cart, address1, address2, payment, customer);
        cart.addItem(item1);
        cart.addItem(item2);
        cart.addItem(item3);
        cart.printItems();
        cart.displayTotal();
        cart.removeItem(0);
        order.ProcessOrder();
        payment.CheckCardType();
        payment.CheckCardNo();
        Email email = new Email(order);
        email.emailCustomer();
                
    }
    
     
}
