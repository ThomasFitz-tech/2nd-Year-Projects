
/**
 * Write a description of class Customer here.
 *
 * @author (Thomas Fitzmaurice)
 * @version (a version number or a date)
 */
public class Customer
{
    private String firstName;
    private String surName;
    private String emailAddress;
    private final double customerId;
    
    public Customer ( String firstName, String surName, String emailAddress)
    {
        this.firstName = firstName;
        this.surName = surName;
        this.emailAddress = emailAddress;
        customerId = makeCustomerId(); 
    }
    
      
    public String getFirstName()
    {
        return firstName;
    }
    
    public String getSurName()
    {
        return surName;
    }
    
    public String getEmail()
    {
        return emailAddress;
    }
    
    public double makeCustomerId()
    {
        double a = Math.random()*(10000-1000+1)+1000;
        return a;
    }
}
